#=================================================================#
# Graphical Forecast Image Configuration File                     #
#                                                                 #
# Meteorological Development Laboratory (MDL)                     #
# LINUX   Python Script                                           #
# January 2005                                                    #
#                                                                 #
#=================================================================#
import os
import time

#-----------------------------------------------------------------#
#                        Time Zone Section                        #
#-----------------------------------------------------------------#
# Set the timezone to PST8PDT, MST7MDT, CST6CDT, EST5EDT, EST5, 
# MST7, depending on Forecast Offices' primary time zone.
os.environ['TZ'] = 'EST5EDT'
time.tzset()

#-----------------------------------------------------------------#
#                     Time Constraint Section                     #
#-----------------------------------------------------------------#
# Different types of time constraints for different element images.
# For short term and extended: start hour, repeat hours, duration
# All times are GMT. 
TimeConstraints = {'TCFree' : (None, None),
                   'TC1' : ((0, 1, 1), (0, 24, 12)),
                   'TC36' : ((0, 3, 1), (0, 6, 1)),
                   'TCPOP' : ((0, 12, 12), (0, 12, 12)),
                   'TCMaxT' : ((12, 24, 12), (12, 24, 12)),
                   'TCMinT' : ((24, 24, 12), (24, 24, 12)),
                   'TC6ST'  : ((0, 6, 6), (0, 6, 6)),
                  }

# The following defines when the day/night periods begin and end
DayNightBoundary = (12, 24)
# The following defines the beginning and end of the short and 
# exteneded forecast periods.
def beginForecast(year, month, day, hour):
    # Beginning of short term forecast: (year, month, day, hour)
    if hour < DayNightBoundary[0]:
       begin = (year, month, day-1, DayNightBoundary[1])
    elif hour < DayNightBoundary[1]:
       begin = (year, month, day, DayNightBoundary[0])
    else:
       begin = (year, month, day, DayNightBoundary[1])
    return begin
       
def beginExtended(year, month, day, hour):
    # Beginning of extended forecast: (year, month, day, hour)
    if hour < DayNightBoundary[0]:
       begin = (year, month, day + 1, DayNightBoundary[0])
    elif hour < DayNightBoundary[1]:
       begin = (year, month, day + 2, DayNightBoundary[1])
    else:
       begin = (year, month, day + 2, DayNightBoundary[0])
    return begin

def endForecast(year, month, day, hour):
    # End of extended period. Just needs to be long enough.
    if hour < DayNightBoundary[0]:
       begin = (year, month, day+7, DayNightBoundary[1])
    elif hour < DayNightBoundary[1]:
       begin = (year, month, day+8, DayNightBoundary[0])
    else:
       begin = (year, month, day+8, DayNightBoundary[1])
    return begin

#-----------------------------------------------------------------#
#                     Weather Element Section                     #
#-----------------------------------------------------------------#
# Element name, data type (SCALAR/WIND/WEATHER), units, label name, 
# experimental image, whether the color table changes seasonally (True/False)
SCALAR = 1
WIND = 2
WEATHER = 3

Elements = {"T" : ('T1hr', SCALAR, "F", "Temperature", " ", True),
            "Td"   : ('Td1hr', SCALAR, "F", "Dewpoint Temperature", " ", True),
            "Wind_Mag" : ("WindSpd1hr", SCALAR, "kts", "WindSpd", " ", False),
            "Weather" : ("Wx1hr", WEATHER, "wx", "Predominant Weather", " ", False),
            "Sky" :  ("Sky1hr", SCALAR, "%", "Sky Cover", " ", False),
            "RH"  :  ("RH1hr", SCALAR, "%", "Relative Humidity", " ", False),
            "Vsby"  :  ("SfcVisibility", SCALAR, "mi", "Visibility", "Experimental*", False),
            "LAL"  :  ("LAL", SCALAR, "cat", "Lightning Activity", " ", False),
            "ApparentT" : ("ApparentT1hr", SCALAR, "F", "Apparent Temp.", " ", True),
            "WindGust" : ("WindGust1hr", SCALAR, "kts", "Wind Gust", " ", False),
            "WaveHeight": ("WaveHeight1hr", SCALAR, "ft", "Wave Height", " ", False),
            "MixHgt" : ("MixHgt1hr", SCALAR, "ft", "Mixing Height", " ", False),
            "Haines" : ("Haines1hr", SCALAR, "cat", "Haines Index", " ", False),
            "TransWind_Mag" : ("TransWind1hr", SCALAR, "kts", "TransWind", " ", False),
            "PoP": ("PoP1hr", SCALAR, "%", "Precip Potential", " ", False),
            }

#-----------------------------------------------------------------#
#                    Data Interpretation Section                  #
#-----------------------------------------------------------------#
# Different ways the image data are to be derived from grids in 
# the netcdf files.
SINGLE = 0 # Get data from the very first grid which overlaps the interval
MAX = 1    # Get the max values of all grids in the interval
MIN = 2    # Get the min values of all grids in the interval
ACCUM = 3  # Add up values from all grids in the interval

# Data source dictionary
# For each element image desired:
# 1. The element characteristics, as given by one of the above 'Elements' 
# 2. The corresponding netcdf grid element
# 3. How the resulting image grid should be derived from the netcdf element
# 4. Time constraints
# 5. Time shift from start of time range for timestamp in output filename.
#    This value is 0 by default.
source_dict = {'T1hr' : ('T', 'T', SINGLE, 'TC1', 0),
               'Td1hr' :   ('Td', 'Td', SINGLE, 'TC1', 0),
               'WindSpd1hr' : ('Wind_Mag', 'Wind_Mag', SINGLE, 'TC1', 0),
               'Wx1hr'   : ('Weather', 'Wx', SINGLE, 'TC1', 0),
               'Sky1hr' :  ('Sky', 'Sky', SINGLE, 'TC1', 0),
               'RH1hr'   : ('RH', 'RH', SINGLE, 'TC1', 0),
               'SfcVisibility1hr'   : ('Vsby', 'Vsby', SINGLE, 'TC1', 0),
               'LAL1hr'   : ('LAL', 'LAL', SINGLE, 'TC1', 0),
               'ApparentT1hr'   : ('ApparentT', 'ApparentT', SINGLE, 'TC1', 0),
               'WindGust1hr' : ('WindGust', 'WindGust', SINGLE, 'TC1', 0),
               'TransWind1hr' :  ('TransWind_Mag', 'TransWind_Mag', SINGLE, 'TC1', 0),
               'WaveHeight1hr' :  ('WaveHeight', 'WaveHeight', MAX, 'TC1', 0),
               'MixHgt1hr' :  ('MixHgt', 'MixHgt', SINGLE, 'TC1', 0),
               'Haines1hr' :  ('Haines', 'Haines', SINGLE, 'TC1', 0),
               'PoP1hr' :  ('PoP', 'PoP', MAX, 'TC1', 0),
              }
                   
#-----------------------------------------------------------------#
#               imageGen Program Arguments Section                #
#-----------------------------------------------------------------#
# Set up the imageGen run with the following:
# -f netCDF file name (ie: GFE_xxxweb.net where xxx is the WFO ID),
# -pdil (progressive disclosure index, pdil - see  the
# cities.sample file for explaination), -defw the pixel width 
# of the image (420px default), -shp shapefile to use for borders,
# -hway name of the highway shapefile to use, --ztime, -credit The
# text to appear at the base of the image between the NWS/NOAA logos.   
prog_args = """\
-f CurrentFcst.okx.cdf -pdil 1,9 -defw 420 -shp uscounty -hway ri11oc01 \
-sample okxcity.sample --ztime \
-credit 'NWS New York, NY'
"""
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
