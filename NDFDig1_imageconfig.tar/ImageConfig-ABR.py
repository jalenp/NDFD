#=================================================================#
# Graphical Forecast Image Configuration File                     #
#                                                                 #
# Meteorological Development Laboratory (MDL)                     #
# LINUX   Python Script                                           #
# January 2005                                                    #
#                                                                 #
# Template for all elements, must change timezone,CurrentFcstxxx  #
#  file call, and Site/State (at bottom).  If elements fail, edit #
#  elements based on elements sent up by site. Go to /database/   #
#  netcdf and run ./ncdump xxxxx.netCDF -h >> outfile.txt, and    #
#  search for strings that do not match and adjust this file in   #
#  two locations below                                            #
#=================================================================#
import os
import time

#-----------------------------------------------------------------#
#                        Time Zone Section                        #
#-----------------------------------------------------------------#
# Set the timezone to PST8PDT, MST7MDT, CST6CDT, EST5EDT, EST5, 
# MST7, depending on Forecast Offices' primary time zone.
os.environ['TZ'] = 'CST6CDT'
time.tzset()

#-----------------------------------------------------------------#
#                     Time Constraint Section                     #
#-----------------------------------------------------------------#
# Different types of time constraints for different element images.
# For short term and extended: start hour, repeat hours, duration
# All times are GMT. 
TimeConstraints = {'TCFree' : (None, None),
                   'TC36' : ((0, 3, 1), (0, 6, 1)),
                   'TCPOP' : ((0, 12, 12), (0, 12, 12)),
                   'TCMaxT' : ((12, 24, 12), (12, 24, 12)),
                   'TCMinT' : ((24, 24, 12), (24, 24, 12)),
                   'TCMinRH' : ((12, 24, 12), (12, 24, 12)),
                   'TCMaxRH' : ((24, 24, 12), (24, 24, 12)),
                   'TC6ST'  : ((0, 6, 6), (0, 6, 6)),
                  }

# The following defines when the day/night periods begin and end
DayNightBoundary = (12, 24)
# The following defines the beginning and end of the short and 
# exteneded forecast periods.
def beginForecast(year, month, day, hour):
    # Beginning of short term forecast: (year, month, day, hour)
    if hour < DayNightBoundary[0]:
       begin = (year, month, day-1, DayNightBoundary[1])
    elif hour < DayNightBoundary[1]:
       begin = (year, month, day, DayNightBoundary[0])
    else:
       begin = (year, month, day, DayNightBoundary[1])
    return begin
       
def beginExtended(year, month, day, hour):
    # Beginning of extended forecast: (year, month, day, hour)
    if hour < DayNightBoundary[0]:
       begin = (year, month, day + 1, DayNightBoundary[0])
    elif hour < DayNightBoundary[1]:
       begin = (year, month, day + 2, DayNightBoundary[1])
    else:
       begin = (year, month, day + 2, DayNightBoundary[0])
    return begin

def endForecast(year, month, day, hour):
    # End of extended period. Just needs to be long enough.
    if hour < DayNightBoundary[0]:
       begin = (year, month, day+7, DayNightBoundary[1])
    elif hour < DayNightBoundary[1]:
       begin = (year, month, day+8, DayNightBoundary[0])
    else:
       begin = (year, month, day+8, DayNightBoundary[1])
    return begin

#-----------------------------------------------------------------#
#                     Weather Element Section                     #
#-----------------------------------------------------------------#
# Element name, data type (SCALAR/WIND/WEATHER), units, label name, 
# experimental label, whether the color table changes seasonally (True/False)
SCALAR = 1
WIND = 2
WEATHER = 3

Elements = {"T" : ('T', SCALAR, "F", "Temperature", " ", True),
            "Td"   : ('Td', SCALAR, "F", "Dewpoint Temperature", " ", True),
            "MaxT" : ("MaxT", SCALAR, "F", "High Temperature", " ", True),
            "MinT" : ("MinT", SCALAR, "F", "Low Temperature", " ", True),
#            "QPF6hr"  : ("QPF", SCALAR, "in", "6Hr Precip.Amt", "Experimental",  False),
            "QPF"  : ("QPF", SCALAR, "in", "6Hr Precip.Amt", "Experimental",  False),
            "Wind_Mag" : ("WindSpd", SCALAR, "kts", "WindSpd", " ", False),
            "WindGust" : ("WindGust", SCALAR, "kts", "Wind Gusts", "Experimental", False),
            "TransWind_Mag" : ("TransWind", SCALAR, "kts", "TransWind", "Experimental", False),
            "FreeWind_Mag" : ("FreeWind", SCALAR, "kts", "Free Air Wind", "Experimental", False),
            "Weather" : ("Wx", WEATHER, "wx", "Predominant Weather", " ", False),
#            "SnowAmt6hr" : ("SnowAmt", SCALAR, "in", "6Hr Snow Amount", "Experimental", False),
            "SnowAmt" : ("SnowAmt", SCALAR, "in", "6Hr Snow Amount", "Experimental", False),
            "MixHgt" : ("MixHgt", SCALAR, "ft", "Mixing Height", "Experimental", False),
            "Haines" : ("Haines", SCALAR, "cat", "Haines Index", "Experimental", False),
            "PoP12": ("PoP12", SCALAR, "%", "12Hr Prob.Precip", " ", False),
            "Sky" :  ("Sky", SCALAR, "%", "Sky Cover", "Experimental", False),
            "RH"  :  ("RH", SCALAR, "%", "Relative Humidity", " ", False),
#            "Vsby"  :  ("Visibility", SCALAR, "mi", "Visibility", "Experimental", False),
            "LAL"  :  ("LAL", SCALAR, "cat", "Lightning Activity", "Experimental", False),
#            "HeatIndex" : ("HeatIndex", SCALAR, "F", "Heat Index", "Experimental", False),
#            "WindChill" : ("WindChill", SCALAR, "F", "Wind Chill", "Experimental", False),
            "ApparentT" : ("ApparentT", SCALAR, "F", "Apparent Temp.", " ", True),
            "WindGust" : ("WindGust", SCALAR, "kts", "Wind Gust", "Experimental", False),
            "MaxRH": ("MaxRH", SCALAR, "%", "Max RH", " ", False),
            "MinRH": ("MinRH", SCALAR, "%", "Min RH", " ", False),
#            "Wind_Mag" : ("WindSpdMarine", SCALAR, "kts", "WindSpd", " ", False),
#            "WindGust" : ("WindGustMarine", SCALAR, "kts", "Wind Gusts", "Experimental", False),
#            "Weather" : ("WxMarine", WEATHER, "wx", "Predominant Weather", " ", False),
#            "PoP12": ("PoP12Marine", SCALAR, "%", "12Hr Prob.Precip", " ", False),
#            "Sky" :  ("SkyMarine", SCALAR, "%", "Sky Cover", "Experimental", False),
            }

#-----------------------------------------------------------------#
#                    Data Interpretation Section                  #
#-----------------------------------------------------------------#
# Different ways the image data are to be derived from grids in 
# the netcdf files.
SINGLE = 0 # Get data from the very first grid which overlaps the interval
MAX = 1    # Get the max values of all grids in the interval
MIN = 2    # Get the min values of all grids in the interval
ACCUM = 3  # Add up values from all grids in the interval

# Data source dictionary
# For each element image desired:
# 1. The element characteristics, as given by one of the above 'Elements' 
# 2. The corresponding netcdf grid element
# 3. How the resulting image grid should be derived from the netcdf element
# 4. Time constraints
# 5. Time shift from start of time range for timestamp in output filename.
#    This value is 0 by default.
source_dict = {'T' : ('T', 'T', SINGLE, 'TC36', 0),
               'Td' :   ('Td', 'Td', SINGLE, 'TC36', 0),
               'MaxT' : ('MaxT', 'MaxT', SINGLE, 'TCFree', 11),
               'MinT' : ('MinT', 'MinT', SINGLE, 'TCFree', 11),
#               'QPF' :  ('QPF6hr', 'QPF6hr', SINGLE, 'TC6ST', 6),
               'QPF' :  ('QPF', 'QPF', SINGLE, 'TC6ST', 6),
               'MixHgt' :  ('MixHgt', 'MixHgt', SINGLE, 'TC36', 0),
               'Haines' :  ('Haines', 'Haines', SINGLE, 'TC36', 0),
               'WindSpd' : ('Wind_Mag', 'Wind_Mag', SINGLE, 'TC36', 0),
               'WindGust' : ('WindGust', 'WindGust', SINGLE, 'TC36', 0),
               'TransWind' :  ('TransWind_Mag', 'TransWind_Mag', SINGLE, 'TC36', 0),
               'FreeWind' :  ('FreeWind_Mag', 'FreeWind_Mag', SINGLE, 'TC6ST', 6),
               'Wx'   : ('Weather', 'Wx', SINGLE, 'TC36', 0),
#               'HeatIndex'   : ('HeatIndex', 'HeatIndex', SINGLE, 'TC36', 0),
#               'WindChill'   : ('WindChill', 'WindChill', SINGLE, 'TC36', 0),
               'ApparentT'   : ('ApparentT', 'ApparentT', SINGLE, 'TC36', 0),
#               'SnowAmt' : ('SnowAmt6hr', 'SnowAmt6hr', SINGLE, 'TC6ST', 6),
                'SnowAmt' : ('SnowAmt', 'SnowAmt', SINGLE, 'TC6ST', 6),
               'PoP12' :  ('PoP12', 'PoP', MAX, 'TCPOP', 12),
               'Sky' :  ('Sky', 'Sky', SINGLE, 'TC36', 0),
               'RH'   : ('RH', 'RH', SINGLE, 'TC36', 0),
               'LAL'   : ('LAL', 'LAL', SINGLE, 'TC36', 0),
               'MaxRH' :  ('MaxRH', 'MaxRH', MAX, 'TCMaxRH', 12),
               'MinRH' :  ('MinRH', 'MinRH', MIN, 'TCMinRH', 12),
              }
                   
#-----------------------------------------------------------------#
#               imageGen Program Arguments Section                #
#-----------------------------------------------------------------#
# Set up the imageGen run with the following:
# -f netCDF file name (ie: GFE_xxxweb.net where xxx is the WFO ID),
# -pdil (progressive disclosure index, pdil - see  the
# cities.sample file for explaination), -defw the pixel width 
# of the image (420px default), -shp shapefile to use for borders,
# -hway name of the highway shapefile to use, --ztime, -credit The
# text to appear at the base of the image between the NWS/NOAA logos.   
prog_args = """\
-f CurrentFcst.abr.cdf -pdil 1,9 -defw 420 -shp uscounty -hway ri11oc01 \
-sample abrcity.sample --ztime \
-credit 'NWS Aberdeen, SD'
"""

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
